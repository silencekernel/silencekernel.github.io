import pyfiglet

# figlet "Moneta" font slant

open('figlet.txt', 'w').write(pyfiglet.figlet_format('Moneta', font='slant'))